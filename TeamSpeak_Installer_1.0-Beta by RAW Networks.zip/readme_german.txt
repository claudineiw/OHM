  _____              __          __    _   _          _                               _          
 |  __ \      /\     \ \        / /   | \ | |        | |                             | |         
 | |__) |    /  \     \ \  /\  / /    |  \| |   ___  | |_  __      __   ___    _ __  | | __  ___ 
 |  _  /    / /\ \     \ \/  \/ /     | . ` |  / _ \ | __| \ \ /\ / /  / _ \  | '__| | |/ / / __|
 | | \ \   / ____ \     \  /\  /      | |\  | |  __/ | |_   \ V  V /  | (_) | | |    |   <  \__ \
 |_|  \_\ /_/    \_\     \/  \/       |_| \_|  \___|  \__|   \_/\_/    \___/  |_|    |_|\_\ |___/
 
 _________________________________________________________________________________________________
 
 Changelog:
 ***************************************
 TeamSpeak 3 Auto Installer Version 1.0 Beta
 ***************************************

Hinzugef�gt: Script Verschl�sselung
Hinzugef�gt: Lizenzsystem
Hinzugef�gt: Blacklist System


 ***************************************
            WICHTIG
 ***************************************
 
 - Es ist nicht erlaubt das TeamSpeak 3 Auto install Script so abzu�ndern, dass der Author RAW Networks nicht mehr in der Information zu erkennen ist. Der Name RAW Networks muss in der Information angezeigt sein.
 - Das TeamSpeak 3 Auto install Script darf auf YouTube vorgestellt werden, aber der Author RAW Networks darf nicht abge�ndert werden. Sollte dies nicht beachtet werden so werden die Videos wegen Urherberrechtsverletzung entfernt.
 
-----------------------------------------------------------------
RAW Networks // YouTube: https://youtube.com/c/RawNetworksYouTube
-----------------------------------------------------------------
 
� RAW Networks
